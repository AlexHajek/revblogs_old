package com.revature.service.impl;

import com.revature.service.ServiceLocator;

public class ServiceLocatorImpl implements ServiceLocator{

}