package com.revature.service;

public interface ServiceLocator {

}
