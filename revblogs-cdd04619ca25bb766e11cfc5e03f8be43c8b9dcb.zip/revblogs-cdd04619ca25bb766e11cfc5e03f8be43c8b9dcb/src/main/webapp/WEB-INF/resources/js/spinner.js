/**
 * 
 */
$(document).ready(function(){
    $('#upload').click(function() {
    	document.getElementById("loading").style = "visibility: visible";
    });
});
